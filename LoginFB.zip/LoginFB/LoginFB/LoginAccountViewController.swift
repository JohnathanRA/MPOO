//
//  LoginAccountViewController.swift
//  LoginFB
//
//  Created by Germán Santos Jaimes on 11/7/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase

class LoginAccountViewController: UIViewController {

    @IBOutlet weak var nombre: UILabel!
    
    var userName: String!
    var userCollectionRef: CollectionReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    override func viewWillAppear(_ animated: Bool) {
        checkIfUserIsLoggedIn()
        
        userCollectionRef = Firestore.firestore().collection("users")
        
        self.userCollectionRef.addSnapshotListener { (snapshot, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
            }else{
                userLoginList.removeAll()
                for document in (snapshot?.documents)!{
                    
                    let data = document.data()
                    let username = data["username"] as! String
                    let date_created = data["date_created"] as! Date ?? Date()
                    let documentID = document.documentID
                    
                    let newUser: User! = User(username: username,date_crated: date_created,ID: documentID)
                    
                    userLoginList.append(newUser)
                }
            }
        }
        nombre.text = userActive2
    }
    
    @IBAction func registerUsers(_ sender: UIButton) {
    }
    
    @IBAction func logoutUser(_ sender: UIButton) {
        handleLogout()
    }
    
    func checkIfUserIsLoggedIn() {
        if Auth.auth().currentUser?.uid == nil{
            perform(#selector(handleLogout), with: nil, afterDelay: 0)
        }else{
            userActive2 = Auth.auth().currentUser?.displayName
        }
    }
    
    @objc func handleLogout() {
        do {
            try Auth.auth().signOut()
        } catch let  logoutError  {
            print(logoutError.localizedDescription)
        }
        performSegue(withIdentifier: "toLogin", sender: nil)
    }
    
}
