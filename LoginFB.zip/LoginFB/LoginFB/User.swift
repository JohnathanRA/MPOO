//
//  User.swift
//  LoginFB
//
//  Created by Macbook on 11/16/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import Foundation

struct User {
    var username: String
    var date_crated: Date
    var ID: String
}

var userActive: User!

var userLoginList = [User]()
