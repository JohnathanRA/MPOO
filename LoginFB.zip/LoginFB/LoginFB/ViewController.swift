//
//  ViewController.swift
//  LoginFB
//
//  Created by Germán Santos Jaimes on 11/7/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var email: UITextField!
    
    var userCollectionRef: CollectionReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userCollectionRef = Firestore.firestore().collection("users")
    }
    
    
    @IBAction func loginUser(_ segue: UIStoryboardSegue) {
        guard let correo = email.text,
            let pass = password.text else { return }
        
        Auth.auth().signIn(withEmail: correo, password: pass) { (data, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
            } else {
                self.userCollectionRef.addSnapshotListener { (snapshot, error) in
                    if let error = error{
                        debugPrint(error.localizedDescription)
                    }else{
                        userLoginList.removeAll()
                        for document in (snapshot?.documents)!{
                            // paso 1
                            //print(document.data())
                            
                            // paso 2
                            let data = document.data()
                            let username = data["username"] as! String
                            let date_created = data["date_created"] as! Date ?? Date()
                            let documentID = document.documentID
                            
                            let newUser: User! = User(username: username,date_crated: date_created,ID: documentID)
                            
                            userLoginList.append(newUser)
                        }
                        
                        for i in 1...userLoginList.count {
                            if userLoginList[i - 1].ID == data?.user.uid {
                                
                                print(userLoginList[i - 1].username)
                                
                                userActive = userLoginList[i - 1]
                                
                                self.performSegue(withIdentifier: "toLoginAccountVC", sender: nil )
                            }
                        }
//                        self.TablaEmpleados.reloadData()
                    }
                    
                }
                print("\n \n \(data?.user.uid)")
            }
        }
    }
}


    
