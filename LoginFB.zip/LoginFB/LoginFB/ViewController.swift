//
//  ViewController.swift
//  LoginFB
//
//  Created by Germán Santos Jaimes on 11/7/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit
import Firebase

class ViewController: UIViewController {

    @IBOutlet weak var password: UITextField!
    @IBOutlet weak var email: UITextField!
    
    var userCollectionRef: CollectionReference!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        userCollectionRef = Firestore.firestore().collection("users")
    }
    
    
    @IBAction func loginUser(_ segue: UIStoryboardSegue) {
        guard let correo = email.text,
            let pass = password.text else { return }
        
        Auth.auth().signIn(withEmail: correo, password: pass) { (data, error) in
            if let error = error{
                debugPrint(error.localizedDescription)
            } else {
                let userActive2 = data?.user.displayName as! String
                
                self.performSegue(withIdentifier: "toLoginAccountVC", sender: nil )
            }
        }
    }
}


    
