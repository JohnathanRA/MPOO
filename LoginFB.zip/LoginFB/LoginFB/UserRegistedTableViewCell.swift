//
//  UserRegistedTableViewCell.swift
//  LoginFB
//
//  Created by Macbook on 11/22/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class UserRegistedTableViewCell: UITableViewCell {

    @IBOutlet weak var userName: UILabel!
    
    @IBOutlet weak var userLogin: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
