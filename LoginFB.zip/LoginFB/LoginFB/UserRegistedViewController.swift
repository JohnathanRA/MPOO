//
//  UserRegistedViewController.swift
//  LoginFB
//
//  Created by Macbook on 11/16/18.
//  Copyright © 2018 Germán Santos Jaimes. All rights reserved.
//

import UIKit

class UserRegistedViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    @IBOutlet weak var tableUsersRegisted: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("\n \n \n hola \n \n")
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userLoginList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableUsersRegisted.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as? UserRegistedTableViewCell
        
        cell?.userName.text = userLoginList[indexPath.row].username
        
        if userLoginList[indexPath.row].username == userActive.username {
            cell?.userLogin.text = "º"
        }
        
        return cell!
    }
}
